﻿using System;

namespace DoublyLinkedList_class
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
